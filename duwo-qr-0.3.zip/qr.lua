-- DUWO QR encoder: byte mode, ECC M, versions 1..10, fixed mask 0.
-- Pure Lua 5.1; no bit library or network. Matrix indexed [y+1][x+1].
local M = {}
local floor = math.floor
local function xor(a, b)
    local n, p = 0, 1
    while a > 0 or b > 0 do
        if a % 2 ~= b % 2 then n = n + p end
        a, b, p = floor(a/2), floor(b/2), p*2
    end
    return n
end
local function mul(a, b)
    local n = 0
    while b > 0 do
        if b % 2 == 1 then n = xor(n, a) end
        a, b = a*2, floor(b/2)
        if a >= 256 then a = xor(a, 285) end
    end
    return n
end
local specs = { -- total codewords, ECC codewords per block, block count
    {26,10,1}, {44,16,1}, {70,26,1}, {100,18,2}, {134,24,2},
    {172,16,4}, {196,18,4}, {242,22,4}, {292,22,5}, {346,26,5},
}
local function append(bits, value, count)
    for i=count-1,0,-1 do bits[#bits+1] = floor(value/2^i)%2 end
end
local function codewords(text, version)
    local spec = specs[version]
    local total, ec, blocks = spec[1], spec[2], spec[3]
    local capacity = total - ec*blocks
    local bits = {}
    -- ECI 26 explicitly declares UTF-8 for international contact names.
    append(bits, 7, 4); append(bits, 26, 8)
    append(bits, 4, 4); append(bits, #text, version < 10 and 8 or 16)
    for i=1,#text do append(bits, text:byte(i), 8) end
    append(bits, 0, math.min(4, capacity*8-#bits))
    while #bits%8 ~= 0 do bits[#bits+1] = 0 end
    local data = {}
    for i=1,#bits,8 do
        local n = 0
        for j=0,7 do n = n*2 + bits[i+j] end
        data[#data+1] = n
    end
    local pad = 236
    while #data < capacity do data[#data+1] = pad; pad = 253-pad end
    -- Reed-Solomon generator, descending coefficients, GF(256)/0x11D.
    local generator, root = {1}, 1
    for i=1,ec do
        local nextg = {}
        for j=1,#generator+1 do nextg[j] = 0 end
        for j=1,#generator do
            nextg[j] = xor(nextg[j], generator[j])
            nextg[j+1] = xor(nextg[j+1], mul(generator[j], root))
        end
        generator, root = nextg, mul(root, 2)
    end
    local short = floor(total/blocks)-ec
    local short_count = blocks-total%blocks
    local chunks, checks, offset = {}, {}, 1
    for b=1,blocks do
        local size = short + (b > short_count and 1 or 0)
        local chunk, remainder = {}, {}
        for i=1,ec do remainder[i] = 0 end
        for i=1,size do
            local value = data[offset]; offset = offset+1; chunk[i] = value
            local factor = xor(value, remainder[1])
            table.remove(remainder, 1); remainder[ec] = 0
            for j=1,ec do remainder[j] = xor(remainder[j], mul(generator[j+1], factor)) end
        end
        chunks[b], checks[b] = chunk, remainder
    end
    local result = {}
    for i=1,short+1 do
        for b=1,blocks do if chunks[b][i] then result[#result+1] = chunks[b][i] end end
    end
    for i=1,ec do for b=1,blocks do result[#result+1] = checks[b][i] end end
    return result
end
function M.encode(text)
    assert(type(text) == 'string' and #text > 0, 'QR-Inhalt fehlt')
    local version
    for v,spec in ipairs(specs) do
        if 12+4+(v<10 and 8 or 16)+#text*8 <= (spec[1]-spec[2]*spec[3])*8 then version=v; break end
    end
    assert(version, 'QR-Inhalt zu lang (maximal 212 UTF-8-Bytes)')
    local size = version*4+17
    local matrix, reserved = {}, {}
    for y=1,size do matrix[y],reserved[y] = {},{} end
    local function put(x,y,dark)
        if x>=0 and y>=0 and x<size and y<size then
            matrix[y+1][x+1],reserved[y+1][x+1] = dark, true
        end
    end
    -- Finder patterns with separators.
    for _,p in ipairs({{3,3},{size-4,3},{3,size-4}}) do
        for dy=-4,4 do for dx=-4,4 do
            local d = math.max(math.abs(dx), math.abs(dy))
            put(p[1]+dx,p[2]+dy,d~=2 and d~=4)
        end end
    end
    for i=8,size-9 do put(6,i,i%2==0); put(i,6,i%2==0) end
    if version>1 then
        local positions = {6,size-7}
        if version>=7 then positions = {6, floor(version/7)*2+16, size-7} end
        -- Versions 7..10 centers: 6,22/24/26/28,38/42/46/50.
        if version>=7 then positions[2] = version*2+8 end
        for yi,cy in ipairs(positions) do for xi,cx in ipairs(positions) do
            local last = #positions
            if not ((xi==1 and yi==1) or (xi==last and yi==1) or (xi==1 and yi==last)) then
                for dy=-2,2 do for dx=-2,2 do
                    put(cx+dx,cy+dy,math.max(math.abs(dx),math.abs(dy))~=1)
                end end
            end
        end end
    end
    -- ECC M has format level bits 00, mask 000. BCH + mandatory XOR.
    local format = 0x5412
    local function bit(n,i) return floor(n/2^i)%2==1 end
    for i=0,5 do put(8,i,bit(format,i)) end
    put(8,7,bit(format,6)); put(8,8,bit(format,7)); put(7,8,bit(format,8))
    for i=9,14 do put(14-i,8,bit(format,i)) end
    for i=0,7 do put(size-1-i,8,bit(format,i)) end
    for i=8,14 do put(8,size-15+i,bit(format,i)) end
    put(8,size-8,true)
    if version>=7 then
        local rem = version
        for i=1,12 do rem = rem*2; if rem>=4096 then rem=xor(rem,0x1F25) end end
        local value = version*4096+rem
        for i=0,17 do
            local a,b = size-11+i%3,floor(i/3)
            put(a,b,bit(value,i)); put(b,a,bit(value,i))
        end
    end
    local bytes = codewords(text,version)
    local data, index = {},1
    for _,b in ipairs(bytes) do append(data,b,8) end
    local right, upward = size-1,true
    while right>=1 do
        if right==6 then right=5 end
        for step=0,size-1 do
            local y = upward and (size-1-step) or step
            for dx=0,1 do
                local x=right-dx
                if not reserved[y+1][x+1] then
                    local dark = (data[index] or 0)==1; index=index+1
                    if (x+y)%2==0 then dark=not dark end
                    matrix[y+1][x+1] = dark
                end
            end
        end
        right,upward = right-2,not upward
    end
    return matrix
end
return M
