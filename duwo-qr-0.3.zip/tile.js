/* Scheduled Player v20: local editor and live SVG preview. */
(function () {
  // Editor-only helpers; no browser or JavaScript runs on the Pi.
  function string(v) { return typeof v === 'string' ? v : ''; }
  function clean(v) { return string(v).trim(); }
  function single(v) { return clean(v).replace(/[\x00-\x1f\x7f]/g, ''); }
  function escapeText(v) { return string(v).replace(/\\/g, '\\\\').replace(/\r\n|\r/g, '\n').replace(/\n/g, '\\n').replace(/;/g, '\\;').replace(/,/g, '\\,'); }
  function requireValue(ok, message) { if (!ok) throw new Error(message); }
  function bytes(s) { return unescape(encodeURIComponent(s)).split('').map(function(c) { return c.charCodeAt(0); }); }
  function fold(lines) {
    var result = [];
    lines.forEach(function(line) {
      var current = '', length = 0;
      Array.from(line).forEach(function(c) {
        var count = bytes(c).length;
        if (length + count > 75) { result.push(current); current = ' '; length = 1; }
        current += c; length += count;
      });
      result.push(current);
    });
    return result.join('\r\n') + '\r\n';
  }
  function dateParts(value) {
    var m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/.exec(string(value));
    requireValue(m, 'Termin: Datum und Uhrzeit fehlen oder sind ungültig');
    var a = m.slice(1).map(Number), d = new Date(Date.UTC(a[0], a[1]-1, a[2], a[3], a[4]));
    requireValue(a[0]>=2000 && a[0]<=2099 && d.getUTCFullYear()===a[0] && d.getUTCMonth()===a[1]-1 &&
      d.getUTCDate()===a[2] && a[3]<=23 && a[4]<=59, 'Termin: ungültiges Datum (2000–2099)');
    return {parts:a,date:d};
  }
  function stamp(value, zone) {
    var parsed=dateParts(value), a=parsed.parts, d=parsed.date, offset=0;
    if (zone === 'Europe/Berlin') {
      var march=31-new Date(Date.UTC(a[0],2,31)).getUTCDay();
      var october=31-new Date(Date.UTC(a[0],9,31)).getUTCDay();
      requireValue(!((a[1]===3 && a[2]===march || a[1]===10 && a[2]===october) && a[3]===2),
        'Termin: 02 Uhr am Zeitumstellungstag vermeiden');
      var summer=a[1]>3 && a[1]<10 || a[1]===3 && (a[2]>march || a[2]===march && a[3]>=3) ||
        a[1]===10 && (a[2]<october || a[2]===october && a[3]<2);
      offset=summer ? 2 : 1;
    } else requireValue(zone === 'UTC', 'Unbekannte Termin-Zeitzone');
    return new Date(d.getTime()-offset*3600000).toISOString().slice(0,19).replace(/[-:]/g,'')+'Z';
  }
  function payload(c) {
    var mode=c.mode || 'url';
    if (mode === 'url') {
      var url=clean(c.url === undefined ? 'https://www.duwo08.de' : c.url);
      requireValue(/^https?:\/\/[^\s/]+/.test(url) && !/[\x00-\x20\x7f]/.test(url), 'HTTP(S)-URL fehlt oder ist ungültig');
      return url;
    }
    if (mode === 'email') {
      var email=single(c.email);
      requireValue(/^[^\s@?&#]+@[^\s@?&#]+\.[^\s@?&#]+$/.test(email), 'E-Mail-Adresse fehlt oder ist ungültig');
      return 'mailto:'+email;
    }
    if (mode === 'phone') {
      var phone=single(c.phone).replace(/[\s()\-.]/g,'');
      requireValue(/^\+?\d+$/.test(phone), 'Telefonnummer fehlt oder ist ungültig');
      return 'tel:'+phone;
    }
    if (mode === 'vcard') {
      var first=single(c.first_name), last=single(c.last_name);
      requireValue(first || last, 'Kontaktname fehlt');
      var card=['BEGIN:VCARD','VERSION:3.0','N:'+escapeText(last)+';'+escapeText(first)+';;;','FN:'+escapeText(clean(first+' '+last))];
      [['ORG',c.organization],['EMAIL',c.email],['TEL',c.phone],['URL',c.contact_url]].forEach(function(f) {
        if (single(f[1])) card.push(f[0]+':'+escapeText(single(f[1])));
      });
      return card.concat(['END:VCARD']).join('\r\n')+'\r\n';
    }
    requireValue(mode === 'event', 'Unbekannter QR-Typ');
    requireValue(single(c.event_title), 'Termin-Titel fehlt');
    var start, end, suffix='';
    if (c.event_all_day) {
      var startDate=dateParts(string(c.event_start_date)+'T12:00').date;
      var endDate=dateParts(string(c.event_end_date)+'T12:00').date;
      requireValue(endDate>=startDate,'Letzter Termintag muss nach oder am ersten Tag liegen');
      start=startDate.toISOString().slice(0,10).replace(/-/g,'');
      end=new Date(endDate.getTime()+86400000).toISOString().slice(0,10).replace(/-/g,'');
      suffix=';VALUE=DATE';
    } else {
      start=stamp(c.event_start,c.event_timezone || 'Europe/Berlin');
      end=stamp(c.event_end,c.event_timezone || 'Europe/Berlin');
      requireValue(end>start,'Termin-Ende muss nach dem Beginn liegen');
    }
    var lines=['BEGIN:VEVENT','SUMMARY:'+escapeText(single(c.event_title)),'DTSTART'+suffix+':'+start,'DTEND'+suffix+':'+end];
    if (single(c.event_location)) lines.push('LOCATION:'+escapeText(single(c.event_location)));
    var description=clean(c.event_description).replace(/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/g,'');
    if (description) lines.push('DESCRIPTION:'+escapeText(description));
    return fold(lines.concat(['END:VEVENT']));
  }
  // Same byte/ECI/M/mask-0 encoder as qr.lua, independently tested against it.
  function encode(text) {
    var input=bytes(text), specs=[[26,10,1],[44,16,1],[70,26,1],[100,18,2],[134,24,2],
      [172,16,4],[196,18,4],[242,22,4],[292,22,5],[346,26,5]];
    var version=specs.findIndex(function(s,v) { return 16+(v<9?8:16)+input.length*8<=(s[0]-s[1]*s[2])*8; })+1;
    requireValue(version && input.length,'QR-Inhalt zu lang (maximal 212 UTF-8-Bytes)');
    var spec=specs[version-1], total=spec[0], ec=spec[1], blocks=spec[2], capacity=total-ec*blocks, bits=[];
    function append(value,count) { for (var i=count-1;i>=0;i--) bits.push((value >>> i)&1); }
    append(7,4);append(26,8);append(4,4);append(input.length,version<10?8:16);
    input.forEach(function(b){append(b,8);});append(0,Math.min(4,capacity*8-bits.length));
    while(bits.length%8)bits.push(0);
    var data=[];
    for(var i=0;i<bits.length;i+=8) { var n=0;for(var j=0;j<8;j++)n=n*2+bits[i+j];data.push(n); }
    var pad=236;while(data.length<capacity){data.push(pad);pad=253-pad;}
    function mul(a,b){var n=0;while(b){if(b&1)n^=a;a<<=1;b>>=1;if(a>=256)a^=285;}return n;}
    var generator=[1],root=1;
    for(i=0;i<ec;i++){var next=Array(generator.length+1).fill(0);generator.forEach(function(g,j){next[j]^=g;next[j+1]^=mul(g,root);});generator=next;root=mul(root,2);}
    var short=Math.floor(total/blocks)-ec,shortCount=blocks-total%blocks,chunks=[],checks=[],offset=0;
    for(var b=0;b<blocks;b++){
      var chunk=data.slice(offset,offset+short+(b>=shortCount?1:0));offset+=chunk.length;
      var remainder=Array(ec).fill(0);
      chunk.forEach(function(value){var factor=value^remainder.shift();remainder.push(0);for(var j=0;j<ec;j++)remainder[j]^=mul(generator[j+1],factor);});
      chunks.push(chunk);checks.push(remainder);
    }
    var words=[];
    for(i=0;i<=short;i++)for(b=0;b<blocks;b++)if(chunks[b][i]!==undefined)words.push(chunks[b][i]);
    for(i=0;i<ec;i++)for(b=0;b<blocks;b++)words.push(checks[b][i]);
    var size=version*4+17,matrix=Array.from({length:size},function(){return Array(size).fill(false);});
    var reserved=Array.from({length:size},function(){return Array(size).fill(false);});
    function put(x,y,dark){if(x>=0&&y>=0&&x<size&&y<size){matrix[y][x]=dark;reserved[y][x]=true;}}
    [[3,3],[size-4,3],[3,size-4]].forEach(function(p){for(var dy=-4;dy<=4;dy++)for(var dx=-4;dx<=4;dx++){var d=Math.max(Math.abs(dx),Math.abs(dy));put(p[0]+dx,p[1]+dy,d!==2&&d!==4);}});
    for(i=8;i<=size-9;i++){put(6,i,i%2===0);put(i,6,i%2===0);}
    if(version>1){var positions=version>=7?[6,version*2+8,size-7]:[6,size-7];positions.forEach(function(cy,yi){positions.forEach(function(cx,xi){var last=positions.length-1;if(!(xi===0&&yi===0||xi===last&&yi===0||xi===0&&yi===last))for(var dy=-2;dy<=2;dy++)for(var dx=-2;dx<=2;dx++)put(cx+dx,cy+dy,Math.max(Math.abs(dx),Math.abs(dy))!==1);});});}
    function bit(n,i){return ((n>>>i)&1)===1;}
    var format=0x5412;
    for(i=0;i<=5;i++)put(8,i,bit(format,i));put(8,7,bit(format,6));put(8,8,bit(format,7));put(7,8,bit(format,8));
    for(i=9;i<=14;i++)put(14-i,8,bit(format,i));for(i=0;i<=7;i++)put(size-1-i,8,bit(format,i));
    for(i=8;i<=14;i++)put(8,size-15+i,bit(format,i));put(8,size-8,true);
    if(version>=7){var rem=version;for(i=0;i<12;i++){rem*=2;if(rem>=4096)rem^=0x1f25;}var value=version*4096+rem;for(i=0;i<18;i++){var a=size-11+i%3,bb=Math.floor(i/3);put(a,bb,bit(value,i));put(bb,a,bit(value,i));}}
    bits=[];words.forEach(function(w){append(w,8);});var index=0,right=size-1,up=true;
    while(right>=1){if(right===6)right=5;for(var step=0;step<size;step++){var y=up?size-1-step:step;for(var dx=0;dx<=1;dx++){var x=right-dx;if(!reserved[y][x]){var dark=(bits[index++]||0)===1;matrix[y][x]=(x+y)%2===0?!dark:dark;}}}right-=2;up=!up;}
    return {matrix:matrix,reserved:reserved};
  }
  function number(value, fallback, low, high) { var n=Number(value);if(value===undefined||!isFinite(n))n=fallback;return Math.floor(Math.max(low,Math.min(high,n))); }
  function textLines(text,size,width,wrap,measure) {
    text=string(text).replace(/\r\n|\r/g,'\n').replace(/[\x00-\x09\x0b-\x1f\x7f]/g,'');
    if(!wrap)text=text.replace(/\n/g,' ');
    var lines=[];
    text.split('\n').forEach(function(paragraph){var line='';var chars=Array.from(paragraph);for(var i=0;i<chars.length;i++){
      var char=chars[i];if(measure(line+char,size)>width){if(wrap&&line){var match=/^(.*)\s+([^\s]*)$/.exec(line);if(match&&match[1]){lines.push(match[1]);line=match[2];}else{lines.push(line);line='';}if(measure(line+char,size)>width&&line){lines.push(line);line='';}}if(!wrap)break;}if(measure(char,size)<=width&&!(line===''&&char===' '))line+=char;
    }lines.push(line);});return lines.slice(0,12);
  }
  function layout(c,n,measure) {
    var W=number(c.preview_width,1920,1,7680),H=number(c.preview_height,1080,1,7680),margin=number(c.margin,16,0,500);
    var size=number(c.size,260,64,1600),fs=number(c.font_size,22,10,96),text=c.text===undefined?'Jetzt scannen':string(c.text),logo=c.show_logo===true;
    var ls=number(c.logo_size,44,16,160),lp=c.logo_position||'left',icon=['phone','calendar'].indexOf(c.hint_icon)>=0?c.hint_icon:'none';
    var present=!!(clean(text)||logo||icon!=='none'),shape=['circle','rounded'].indexOf(c.panel_shape)>=0?c.panel_shape:'rectangle';
    var radius=number(c.corner_radius,20,0,120),padding=number(c.padding,12,0,120);
    if(shape==='rounded')padding=Math.max(padding,Math.ceil(radius*(1-1/Math.sqrt(2)))+1);
    var pos=['above','left','right'].indexOf(c.text_position)>=0?c.text_position:'below',horizontal=pos==='left'||pos==='right';
    function dimensions(q){var bw=horizontal?number(c.text_width,220,60,600):q,tw=bw;
      if(logo&&(lp==='left'||lp==='right'))tw-=ls+10;if(icon!=='none')tw-=fs+8;tw=Math.max(1,tw);
      var lines=textLines(text,fs,tw,c.text_wrap===true,measure),lh=Math.ceil(fs*1.25),th=clean(text)?lines.length*lh:0;
      if(icon!=='none')th=Math.max(th,fs);var bh=Math.max(64,th+20);
      if(logo)bh=lp==='above'||lp==='below'?Math.max(64,th+ls+30):Math.max(bh,ls+20);
      var iw=q,ih=q;if(present){if(horizontal){iw=q+12+bw;ih=Math.max(q,bh);}else ih=q+bh;}
      var cw=iw+2*padding,ch=ih+2*padding,pw=cw,ph=ch;if(shape==='circle'){pw=Math.ceil(Math.sqrt(cw*cw+ch*ch))+8;ph=pw;}
      return {w:pw,h:ph,cw:cw,ch:ch,bw:bw,bh:bh,tw:tw,th:th,lines:lines,lh:lh};}
    var d=dimensions(size);if(d.w+margin*2>W||d.h+margin*2>H){var lo=0,hi=size;while(lo<hi){var mid=Math.ceil((lo+hi)/2),v=dimensions(mid);if(v.w+margin*2<=W&&v.h+margin*2<=H)lo=mid;else hi=mid-1;}size=lo;d=dimensions(size);}
    requireValue(!clean(text)||d.tw>=fs,'Textfläche zu schmal: Textbreite vergrößern oder Logo/Symbol verkleinern');
    requireValue(!logo||d.bw>=ls,'Logo zu groß: Logo verkleinern oder QR-Fläche vergrößern');
    var scale=Math.floor(size/(n+8));requireValue(scale>=2&&d.w+margin*2<=W&&d.h+margin*2<=H,'QR zu klein: Element vergrößern oder Text/Logo verkleinern');
    var x=margin,y=margin,position=c.position||'bottom_right';if(position==='custom'){x=number(c.x,16,0,Math.max(0,W-d.w));y=number(c.y,16,0,Math.max(0,H-d.h));}
    else{if(position.indexOf('right')>=0)x=W-d.w-margin;if(position.indexOf('bottom')>=0)y=H-d.h-margin;if(position==='center'){x=Math.floor((W-d.w)/2);y=Math.floor((H-d.h)/2);}}
    var cx=x+Math.floor((d.w-d.cw)/2),cy=y+Math.floor((d.h-d.ch)/2),qx=cx+padding,qy=cy+padding,bx=qx,by=qy;
    if(present){if(horizontal){qy+=Math.floor((d.ch-2*padding-size)/2);by+=Math.floor((d.ch-2*padding-d.bh)/2);if(pos==='left')qx+=d.bw+12;else bx+=size+12;}else if(pos==='above')qy+=d.bh;else by+=size;}
    var tx=bx,ty=by+Math.floor((d.bh-d.th)/2),lx=bx,ly=by+Math.floor((d.bh-ls)/2);
    if(logo){if(lp==='right')lx=bx+d.bw-ls;else if(lp==='above'||lp==='below'){lx=bx+Math.floor((d.bw-ls)/2);var top=by+Math.floor((d.bh-d.th-ls-10)/2);if(lp==='above'){ly=top;ty=top+ls+10;}else{ty=top;ly=top+d.th+10;}}else tx+=ls+10;}
    var ix=tx,iy=ty;if(icon!=='none')tx+=fs+8;
    return Object.assign(d,{x:x,y:y,cx:cx,cy:cy,qx:qx+Math.floor((size-(n+8)*scale)/2),qy:qy+Math.floor((size-(n+8)*scale)/2),scale:scale,side:(n+8)*scale,
      shape:shape,radius:radius,fs:fs,logo:logo,lx:lx,ly:ly,ls:ls,tx:tx,ty:ty,icon:icon,ix:ix,iy:iy});
  }
  function xml(s){return string(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
  function color(s,fallback){return /^#[0-9a-f]{6}$/i.test(s)?s:fallback;}
  function svgPreview(c,qr,p,measure){
    var bg=color(c.background_color,'#061430'),accent=color(c.accent_color,'#cc1429'),fg=color(c.text_color,'#ffffff');
    var opacity=number(c.background_opacity,100,0,100)/100,t=number(c.accent_thickness,4,0,32),items=[];
    function rect(x,y,w,h,fill,attrs){items.push('<rect x="'+x+'" y="'+y+'" width="'+w+'" height="'+h+'" fill="'+fill+'" '+(attrs||'')+'/>');}
    var shape=p.shape==='circle'?'<circle cx="'+(p.x+p.w/2)+'" cy="'+(p.y+p.h/2)+'" r="'+p.w/2+'"/>':
      '<rect x="'+p.x+'" y="'+p.y+'" width="'+p.w+'" height="'+p.h+'" rx="'+(p.shape==='rounded'?p.radius:0)+'"/>';
    var id='duwo-preview-mask-'+number(c.preview_id,0,0,999999);items.push('<defs><clipPath id="'+id+'">'+shape+'</clipPath></defs><g clip-path="url(#'+id+')">');
    rect(p.x,p.y,p.w,p.h,bg,'opacity="'+opacity+'"');
    if(p.shape==='circle')items.push('<path d="M '+(p.x+t/2)+' '+(p.y+p.h/2)+' A '+(p.w/2-t/2)+' '+(p.h/2-t/2)+' 0 0 1 '+(p.x+p.w-t/2)+' '+(p.y+p.h/2)+'" fill="none" stroke="'+accent+'" stroke-width="'+t+'"/>');
    else rect(p.x,p.y,p.w,t,accent);items.push('</g>');
    if(c.effect==='pulse'||c.effect==='glow'){
      var ec=c.effect_custom_color?color(c.effect_color,accent):accent;
      var intensity=number(c.effect_intensity,40,0,100)/100,period={slow:6,normal:4,fast:2}[c.effect_speed]||4;
      var rim=p.shape==='circle'?'<circle cx="'+(p.x+p.w/2)+'" cy="'+(p.y+p.h/2)+'" r="'+(p.w/2-1.5)+'"':
        '<rect x="'+(p.x+1.5)+'" y="'+(p.y+1.5)+'" width="'+(p.w-3)+'" height="'+(p.h-3)+'" rx="'+(p.shape==='rounded'?Math.max(0,p.radius-1.5):0)+'"';
      items.push('<g clip-path="url(#'+id+')" opacity="'+intensity*0.25+'"><animate attributeName="opacity" values="'+intensity*0.25+';'+intensity+';'+intensity*0.25+'" dur="'+period+'s" repeatCount="indefinite" calcMode="spline" keyTimes="0;0.5;1" keySplines="0.42 0 0.58 1;0.42 0 0.58 1"/>');
      if(c.effect==='glow')items.push(rim+' fill="none" stroke="'+ec+'" stroke-width="16" opacity="0.12"/>',rim+' fill="none" stroke="'+ec+'" stroke-width="9" opacity="0.25"/>');
      items.push(rim+' fill="none" stroke="'+ec+'" stroke-width="3"/></g>');
    }
    rect(p.qx,p.qy,p.side,p.side,'white');
    qr.matrix.forEach(function(row,y){row.forEach(function(dark,x){if(!dark)return;var xx=p.qx+(x+4)*p.scale,yy=p.qy+(y+4)*p.scale;
      if(c.module_style==='dots'&&!qr.reserved[y][x])items.push('<circle cx="'+(xx+p.scale/2)+'" cy="'+(yy+p.scale/2)+'" r="'+p.scale/2+'" fill="black"/>');
      else rect(xx,yy,p.scale,p.scale,'black');});});
    if(p.logo){rect(p.lx,p.ly,p.ls,p.ls,'none','stroke="'+fg+'" stroke-dasharray="3 2"');items.push('<text x="'+(p.lx+p.ls/2)+'" y="'+(p.ly+p.ls/2)+'" text-anchor="middle" fill="'+fg+'" font-size="12">Logo</text>');}
    if(p.icon!=='none'){var iw=p.icon==='phone'?p.fs*0.65:p.fs;rect(p.ix,p.iy,iw,p.fs,'none','stroke="'+fg+'" stroke-width="2"');
      if(p.icon==='calendar')rect(p.ix,p.iy+p.fs*0.28,iw,2,fg);else rect(p.ix+iw*0.4,p.iy+p.fs-5,iw*0.2,2,fg);}
    p.lines.forEach(function(line,i){var x=p.tx,w=measure(line,p.fs);if(c.text_align==='center')x+=Math.floor((p.tw-w)/2);if(c.text_align==='right')x+=p.tw-w;
      items.push('<text x="'+x+'" y="'+(p.ty+i*p.lh)+'" dominant-baseline="text-before-edge" fill="'+fg+'" font-family="sans-serif" font-size="'+p.fs+'">'+xml(line)+'</text>');});
    var page=c.preview_mode==='page';var view=page?'0 0 '+number(c.preview_width,1920,1,7680)+' '+number(c.preview_height,1080,1,7680):
      [p.x-12,p.y-12,p.w+24,p.h+24].join(' ');
    return '<svg xmlns="http://www.w3.org/2000/svg" role="img" aria-label="QR-Vorschau" viewBox="'+view+'" style="display:block;width:100%;max-height:360px;background:#999">'+items.join('')+'</svg>';
  }
  var defaults = {
    event_title:'',event_start:'',event_end:'',event_timezone:'Europe/Berlin',event_location:'',event_description:'',
    event_all_day:false,event_start_date:'',event_end_date:'',
    mode:'url',url:'https://www.duwo08.de',email:'',phone:'',first_name:'',last_name:'',organization:'TSV DUWO 08',contact_url:'',
    position:'bottom_right',x:16,y:16,margin:16,size:260,text:'Jetzt scannen',show_logo:false,
    text_align:'left',module_style:'square',panel_shape:'rectangle',text_color:'#ffffff',background_color:'#061430',accent_color:'#cc1429',
    font_size:22,text_wrap:false,text_position:'below',text_width:220,padding:12,corner_radius:20,accent_thickness:4,
    effect:'off',effect_speed:'normal',effect_intensity:40,effect_custom_color:false,effect_color:'#cc1429',
    background_opacity:100,logo_size:44,logo_position:'left',hint_icon:'none',preview_width:1920,preview_height:1080,preview_mode:'card'
  };
  var fields = [
    ['event_title','Termin-Titel','text'],['event_start','Beginn','datetime-local'],['event_end','Ende','datetime-local'],
    ['event_start_date','Erster Termintag','date'],['event_end_date','Letzter Termintag (einschließlich)','date'],
    ['event_location','Veranstaltungsort (optional)','text'],['url','Ziel-URL (HTTP oder HTTPS)','url'],
    ['email','E-Mail-Adresse','email'],['phone','Telefonnummer','tel'],['first_name','Vorname','text'],['last_name','Nachname','text'],
    ['organization','Organisation','text'],['contact_url','Kontakt-Webseite','url'],
    ['font_size','Schriftgröße (10–96 px)','number',10,96],['text_width','Textbreite bei seitlichem Text (60–600 px)','number',60,600],
    ['text_color','Schriftfarbe','color'],['background_color','Hintergrundfarbe','color'],['accent_color','Akzentfarbe','color'],
    ['effect_intensity','Effektintensität (0–100 %)','number',0,100],['effect_color','Eigene Effektfarbe','color'],
    ['background_opacity','Hintergrund-Deckkraft (0 = transparent, 100 = deckend)','number',0,100],
    ['padding','Innenabstand (0–120 px)','number',0,120],['corner_radius','Eckenradius (0–120 px)','number',0,120],
    ['accent_thickness','Akzentstärke (0–32 px)','number',0,32],['logo_size','Logo-Größe (16–160 px)','number',16,160],
    ['size','QR-Zielfläche inkl. Ruhezone (64–1600 px)','number',64,1600],['margin','Randabstand (px)','number',0,500],
    ['x','X relativ zur Elementfläche (px)','number',0,7680],['y','Y relativ zur Elementfläche (px)','number',0,7680],
    ['preview_width','Vorschau: Elementbreite (px)','number',1,7680],['preview_height','Vorschau: Elementhöhe (px)','number',1,7680]
  ];
  var computed={};
  Object.keys(defaults).forEach(function(key){
    computed[key]=ChildTile.config_value(key,defaults[key],typeof defaults[key]==='number'?function(value){var n=Number(value);return isFinite(n)?Math.round(n):defaults[key];}:undefined);
  });
  computed.settings=function(){var self=this,c={};Object.keys(defaults).forEach(function(k){c[k]=self[k];});return c;};
  computed.payload_status=function(){try{var content=payload(this.settings),count=bytes(content).length;return {content:content,bytes:count,error:count>212?'QR-Inhalt zu lang: '+count+' von 212 UTF-8-Bytes. Felder kürzen.':''};}catch(e){return {bytes:0,error:e.message};}};
  computed.qr_data=function(){return this.payload_status.error?null:encode(this.payload_status.content);};
  computed.preview=function(){if(!this.qr_data)return {svg:'',error:''};try{
    var self=this,measure=function(text,size){return self.measureText(text,size);},p=layout(this.settings,this.qr_data.matrix.length,measure);
    return {svg:svgPreview(Object.assign({},this.settings,{preview_id:this._uid||0}),this.qr_data,p,measure),error:'',scale:p.scale};
  }catch(e){return {svg:'',error:e.message};}};
  function select(key,label,options,condition){return '<div class="form-group"'+(condition?' v-if="'+condition+'"':'')+'><label>'+label+
    '<select class="form-control" v-model="'+key+'">'+options.map(function(o){return '<option value="'+o[0]+'">'+o[1]+'</option>';}).join('')+'</select></label></div>';}
  var contentInputs='',designInputs='',previewInputs='';
  fields.forEach(function(f){var key=f[0],condition={url:"mode === 'url'",email:"mode === 'email' || mode === 'vcard'",phone:"mode === 'phone' || mode === 'vcard'",
    first_name:"mode === 'vcard'",last_name:"mode === 'vcard'",organization:"mode === 'vcard'",contact_url:"mode === 'vcard'",
    event_start:"mode === 'event' && !event_all_day",event_end:"mode === 'event' && !event_all_day",
    event_start_date:"mode === 'event' && event_all_day",event_end_date:"mode === 'event' && event_all_day",
    effect_intensity:"effect !== 'off'",effect_color:"effect !== 'off' && effect_custom_color",
    logo_size:'show_logo',corner_radius:"panel_shape === 'rounded'",text_width:"text_position === 'left' || text_position === 'right'",
    x:"position === 'custom'",y:"position === 'custom'"}[key];
    if(key.indexOf('event_')===0&&!condition)condition="mode === 'event'";
    var input='<div class="form-group"'+(condition?' v-if="'+condition+'"':'')+'><label>'+f[1]+
      '<input class="form-control" type="'+f[2]+'" v-model="'+key+'"'+(f[2]==='number'?' min="'+f[3]+'" max="'+f[4]+'" step="1"':'')+'></label></div>';
    if(key.indexOf('preview_')===0)previewInputs+=input;
    else if(['effect_intensity','effect_color','font_size','text_width','text_color','background_color','accent_color','background_opacity','padding','corner_radius','accent_thickness','logo_size','size','margin','x','y'].indexOf(key)>=0)designInputs+=input;
    else contentInputs+=input;
  });
  ChildTile.register({config:{
    props:['config'],data:function(){return {preset:''};},computed:computed,
    methods:{
      measureText:function(text,size){
        if(!this._duwoCanvas)this._duwoCanvas=document.createElement('canvas');
        var context=this._duwoCanvas.getContext('2d');context.font=size+'px sans-serif';return context.measureText(text).width;
      },
      applyPreset:function(){
        var presets={member:{mode:'url',text:'Mitglied werden',panel_shape:'rounded',hint_icon:'phone',url:''},
          training:{mode:'url',text:'Zum Probetraining',panel_shape:'rounded',hint_icon:'phone',url:''},
          donate:{mode:'url',text:'DUWO unterstützen',panel_shape:'circle',hint_icon:'phone',url:''},
          match:{mode:'event',event_title:'DUWO Spieltermin',text:'Termin speichern',panel_shape:'rounded',hint_icon:'calendar'}};
        var chosen=presets[this.preset];if(!chosen)return;
        var values=Object.assign({text_align:'center',text_wrap:true,font_size:22,text_position:'below',text_color:'#ffffff',background_color:'#061430',
          accent_color:'#cc1429',background_opacity:100,padding:12,corner_radius:20,accent_thickness:4,module_style:'square'},chosen);
        var self=this;Object.keys(values).forEach(function(k){self.$emit('setConfig',k,values[k]);});
      },
      // Also exercised by the editor/runtime parity tests.
      buildPayload:payload,encodeQR:encode,buildLayout:layout
    },
    template:'<div><h4>DUWO QR 0.3</h4>'+
      '<div class="well"><strong>Live-Vorschau</strong><div v-if="preview.svg" v-html="preview.svg"></div>'+
      '<p class="text-danger" v-if="payload_status.error">{{payload_status.error}}</p>'+
      '<p v-else>{{payload_status.bytes}} / 212 UTF-8-Bytes <span v-if="payload_status.bytes > 180">– fast voll, Inhalte kurz halten.</span></p>'+
      '<p class="text-danger" v-if="preview.error">{{preview.error}}</p>'+
      '<p v-if="preview.scale && preview.scale < 6">Für größere Betrachtungsabstände und Punkte die QR-Fläche vergrößern.</p>'+
      '<p>Vorschau auf der unten eingestellten Testfläche; Player-Elementgröße separat setzen. Schrift kann leicht abweichen. ' +
      'Das ausgewählte Logo wird als Platzhalter dargestellt.</p></div>'+
      select('preview_mode','Vorschauansicht',[['card','Element vergrößert'],['page','Position auf Testfläche']])+previewInputs+
      '<div class="form-group"><label>Designvorlage<select class="form-control" v-model="preset"><option value="">Bitte wählen</option>'+
      '<option value="member">Mitglied werden</option><option value="training">Probetraining</option><option value="donate">Spenden</option><option value="match">Spieltermin</option></select></label>'+
      '<button type="button" class="btn btn-default" :disabled="!preset" @click="applyPreset">Vorlage anwenden</button>'+
      '<p>Übernimmt Design und Beschriftung. Für Linkvorlagen anschließend die passende Ziel-URL eingeben.</p></div>'+
      select('mode','Inhalt',[['url','Webseite'],['email','E-Mail'],['phone','Telefon'],['vcard','Kontakt (vCard)'],['event','Kalendertermin']])+
      '<div v-if="mode === \'event\'"><label><input type="checkbox" v-model="event_all_day"> Ganztägiger Termin</label></div>'+
      select('event_timezone','Termin-Zeitzone',[['Europe/Berlin','Deutschland (Europe/Berlin)'],['UTC','UTC']],"mode === 'event' && !event_all_day")+
      '<div v-if="mode === \'event\'" class="form-group"><label>Beschreibung (optional)<textarea class="form-control" v-model="event_description"></textarea></label>'+
      '<p>Bei Uhrzeiten wird deutsche Sommer-/Winterzeit berücksichtigt. 02 Uhr an Umstellungstagen vermeiden. Ganztägige Termine schließen den letzten ausgewählten Tag ein.</p></div>'+
      contentInputs+select('panel_shape','Hintergrundform',[['rectangle','Rechteck (Standard)'],['rounded','Abgerundetes Rechteck'],['circle','Kreis']])+
      select('effect','Animation',[['off','Aus (Standard)'],['pulse','Pulsierender Rahmen'],['glow','Dezenter Leuchtring']])+
      select('effect_speed','Geschwindigkeit',[['slow','Langsam (6 Sekunden)'],['normal','Normal (4 Sekunden)'],['fast','Schnell (2 Sekunden)']],"effect !== 'off'")+
      '<label v-if="effect !== \'off\'"><input type="checkbox" v-model="effect_custom_color"> Eigene Effektfarbe verwenden</label>'+
      '<p v-if="effect !== \'off\'">Standardfarbe ist die gewählte Akzentfarbe. Nur der äußere Rand pulsiert; QR-Code und Ruhezone bleiben unverändert.</p>'+
      select('module_style','QR-Design',[['square','Quadrate (Standard)'],['dots','Runde Punkte']])+
      '<p>Kreise brauchen mehr Platz. Erkennungs- und Funktionsmuster des QR-Codes bleiben eckig.</p>'+
      select('position','Position auf der Elementfläche',[['top_left','Oben links'],['top_right','Oben rechts'],['bottom_left','Unten links'],['bottom_right','Unten rechts'],['center','Mitte'],['custom','Freie Koordinaten']])+
      '<div class="form-group"><label>Begleittext (bis 12 Zeilen)<textarea class="form-control" v-model="text"></textarea></label></div>'+
      '<label><input type="checkbox" v-model="text_wrap"> Zeilenumbrüche / automatischer Umbruch</label>'+
      select('text_position','Textposition',[['above','Oberhalb'],['below','Unterhalb (Standard)'],['left','Links'],['right','Rechts']])+
      select('text_align','Textausrichtung',[['left','Linksbündig'],['center','Mittig'],['right','Rechtsbündig']])+
      select('hint_icon','Scan-Symbol',[['none','Kein Symbol'],['phone','Smartphone'],['calendar','Kalender']])+
      '<label><input type="checkbox" v-model="show_logo"> DUWO-Logo anzeigen</label>'+
      select('logo_position','Logo relativ zum Text',[['left','Links'],['right','Rechts'],['above','Oberhalb'],['below','Unterhalb']],'show_logo')+
      designInputs+
      '<p>Logo im Plugin-Reiter auswählen. Hintergrund-Deckkraft 0 blendet die Fläche aus; QR-Ruhezone und Akzent bleiben sichtbar. Akzentstärke 0 blendet auch den Akzent aus.</p>'+
      '<p>Für Positionierung auf der ganzen Seite die Elementfläche im Player entsprechend vergrößern. ' +
      'QR vor den Hintergrund bringen; Raw-Videos und Streams auf „Show behind other content“ stellen.</p></div>'
  }});

}());
