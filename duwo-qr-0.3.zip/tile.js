/* Scheduled Player v20: ChildTile.register + config_value (Vue 2). */
(function () {
  var defaults = {
    mode: 'url', url: 'https://www.duwo08.de', email: '', phone: '',
    first_name: '', last_name: '', organization: 'TSV DUWO 08', contact_url: '',
    position: 'bottom_right', x: 16, y: 16, margin: 16, size: 260,
    text: 'Jetzt scannen', show_logo: false
  };
  var fields = [
    ['url', 'URL (http:// oder https://)', 'url'],
    ['email', 'E-Mail-Adresse', 'email'], ['phone', 'Telefonnummer', 'tel'],
    ['first_name', 'Vorname', 'text'], ['last_name', 'Nachname', 'text'],
    ['organization', 'Organisation', 'text'], ['contact_url', 'Kontakt-Webseite', 'url'],
    ['text', 'Begleittext (optional, eine Zeile)', 'text'],
    ['size', 'QR-Zielfläche inkl. Ruhezone (Pixel)', 'number'],
    ['margin', 'Randabstand (Pixel)', 'number'],
    ['x', 'X relativ zur Elementfläche (Pixel)', 'number'],
    ['y', 'Y relativ zur Elementfläche (Pixel)', 'number']
  ];
  var computed = {};
  Object.keys(defaults).forEach(function (key) {
    var numeric = ['x', 'y', 'margin', 'size'].indexOf(key) !== -1;
    computed[key] = ChildTile.config_value(key, defaults[key], numeric ? function (value) {
      var n = Number(value);
      return isFinite(n) ? Math.round(n) : defaults[key];
    } : undefined);
  });
  var inputs = fields.map(function (field) {
    var key = field[0];
    var condition = {
      url: "mode === 'url'", email: "mode === 'email' || mode === 'vcard'",
      phone: "mode === 'phone' || mode === 'vcard'",
      first_name: "mode === 'vcard'", last_name: "mode === 'vcard'",
      organization: "mode === 'vcard'", contact_url: "mode === 'vcard'",
      x: "position === 'custom'", y: "position === 'custom'"
    }[key];
    return '<div class="form-group"' + (condition ? ' v-if="' + condition + '"' : '') + '>' +
      '<label>' + field[1] + '<input class="form-control" type="' + field[2] +
      '" v-model="' + key + '"' + (field[2] === 'number' ? ' min="0" step="1"' : '') +
      '></label></div>';
  }).join('');
  ChildTile.register({config: {
    props: ['config'],
    computed: computed,
    template: '<div>' +
      '<h4>DUWO QR 0.3</h4>' +
      '<p>Maximal 212 UTF-8-Bytes einschließlich vCard-Feldern. Lange Inhalte benötigen größere QR-Flächen.</p>' +
      '<div class="form-group"><label>Inhalt <select class="form-control" v-model="mode">' +
      '<option value="url">Webseite</option><option value="email">E-Mail</option>' +
      '<option value="phone">Telefon</option><option value="vcard">Kontakt (vCard 3.0)</option>' +
      '</select></label></div>' +
      '<div class="form-group"><label>Position innerhalb der Elementfläche ' +
      '<select class="form-control" v-model="position">' +
      '<option value="top_left">Oben links</option><option value="top_right">Oben rechts</option>' +
      '<option value="bottom_left">Unten links</option><option value="bottom_right">Unten rechts</option>' +
      '<option value="center">Mitte</option><option value="custom">Freie Koordinaten</option>' +
      '</select></label></div>' + inputs +
      '<label><input type="checkbox" v-model="show_logo"> DUWO-Logo anzeigen</label>' +
      '<p>Logo im Plugin-Reiter auswählen. Es erscheint neben dem Text, außerhalb des QR-Codes.</p>' +
      '<p>Für Positionen auf der gesamten Seite die Elementfläche auf die Seitengröße setzen. ' +
      'Das QR-Element in der Ebenenliste vor den Hintergrund bringen. ' +
      'Bei Raw-Videos und Streams „Show behind other content“ wählen.</p></div>'
  }});
}());
