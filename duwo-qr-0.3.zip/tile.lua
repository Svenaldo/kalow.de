local api = ...
-- Nested plugin modules must be explicitly localized: require() searches the parent.
local function local_module(name)
    return assert(loadstring(resource.load_file(api.localized(name))))()
end
local qr = local_module('qr.lua')
local model = local_module('model.lua')
local navy = resource.create_colored_texture(0.025,0.08,0.19,1)
local colored = resource.create_shader[[
    uniform sampler2D Texture;
    varying vec2 TexCoord;
    uniform vec4 color;
    void main() {
        gl_FragColor = texture2D(Texture, TexCoord) * color;
    }
]]
-- Repeats a circular mask along each horizontal run; no per-module textures.
local dotted = resource.create_shader[[
    uniform sampler2D Texture;
    varying vec2 TexCoord;
    uniform float columns;
    uniform float feather;
    void main() {
        vec2 point = vec2(fract(TexCoord.x * columns), TexCoord.y) - vec2(0.5);
        float alpha = 1.0 - smoothstep(0.5 - feather, 0.5, length(point));
        gl_FragColor = texture2D(Texture, TexCoord) * alpha;
    }
]]
local white = resource.create_colored_texture(1,1,1,1)
local black = resource.create_colored_texture(0,0,0,1)
-- The verified Scheduled Player loads this same font in its root namespace.
local font = resource.load_font('default-font.ttf')
local logo
local cache,order = {},{}
local M = {}
function M.updated_config_json(config)
    if logo then logo:dispose(); logo=nil end
    if config.logo and config.logo.asset_name then
        logo=resource.load_image(api.localized(config.logo.asset_name))
    end
end
local function prepare(payload)
    if cache[payload] then return cache[payload] end
    local matrix,reserved=qr.encode(payload)
    local runs={}
    for y,row in ipairs(matrix) do
        local x=1
        while x<=#row do
            if row[x] then
                local start=x
                local functional=reserved[y][x]==true
                repeat x=x+1 until x>#row or not row[x] or (reserved[y][x]==true)~=functional
                runs[#runs+1]={start-1,y-1,x-start,functional}
            else x=x+1 end
        end
    end
    local result={modules=#matrix,runs=runs}
    cache[payload]=result; order[#order+1]=payload
    if #order>8 then cache[table.remove(order,1)]=nil end
    return result
end
local function rectangle(color,x1,y1,x2,y2)
    colored:use{color=color}
    white:draw(x1,y1,x2,y2)
    colored:deactivate()
end
local function label(text,x,y,size,max_width,align,color)
    -- Bound font width without splitting a UTF-8 codepoint.
    local value=text
    while #value>0 and font:width(value,size)>max_width do
        value=value:gsub('[%z\1-\127\194-\244][\128-\191]*$','')
    end
    local width=font:width(value,size)
    if align=='center' then x=x+math.floor((max_width-width)/2)
    elseif align=='right' then x=x+max_width-width end
    color=color or {1,1,1,1}
    font:write(x,y,value,size,color[1],color[2],color[3],color[4])
end
function M.task(starts,ends,config,x1,y1,x2,y2)
    local ok,prepared=pcall(function() return prepare(model.payload(config)) end)
    local background=model.color(config.background_color,{0.025,0.08,0.19,1})
    local accent=model.color(config.accent_color,{0.8,0.08,0.16,1})
    local text_color=model.color(config.text_color,{1,1,1,1})
    local layout,err
    if ok then layout,err=model.layout(config,x1,y1,x2,y2,prepared.modules) end
    if not ok or not layout then
        -- Do not log private URLs/contact data from an encoder exception.
        print('DUWO QR: ungültige Konfiguration oder Element zu klein')
    end
    for now in api.frame_between(starts,ends) do
        if ok and layout then
            local p=layout
            rectangle(background,p.x,p.y,p.x+p.w,p.y+p.h)
            rectangle(accent,p.x,p.y,p.x+p.w,p.y+4)
            white:draw(p.qx,p.qy,p.qx+p.side,p.qy+p.side)
            local s=p.scale
            for _,run in ipairs(prepared.runs) do
                local x,y=p.qx+(run[1]+4)*s,p.qy+(run[2]+4)*s
                local round=config.module_style=='dots' and not run[4]
                if round then dotted:use{columns=run[3],feather=0.5/s} end
                black:draw(x,y,x+run[3]*s,y+s)
                if round then dotted:deactivate() end
            end
            if p.footer>0 then
                local tx=p.x+12
                local ty=p.y+p.h-54
                if p.logo and logo then
                    util.draw_correct(logo,tx,ty,tx+44,ty+44)
                    tx=tx+54
                end
                label(p.text,tx,ty+10,22,p.x+p.w-12-tx,config.text_align,text_color)
            end
        elseif x2-x1>=160 and y2-y1>=50 then
            navy:draw(x1,y1,x2,math.min(y2,y1+50))
            label('QR prüfen: Inhalt / Größe',x1+8,y1+10,20,x2-x1-16)
        end
    end
end
function M.unload()
    if logo then logo:dispose() end
    navy:dispose(); colored:dispose(); dotted:dispose(); white:dispose(); black:dispose()
end
return M
