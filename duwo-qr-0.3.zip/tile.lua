local api = ...
-- Nested plugin modules must be explicitly localized: require() searches the parent.
local function local_module(name)
    return assert(loadstring(resource.load_file(api.localized(name))))()
end
local qr = local_module('qr.lua')
local model = local_module('model.lua')
local navy = resource.create_colored_texture(0.025,0.08,0.19,1)
local colored = resource.create_shader[[
    uniform sampler2D Texture;
    varying vec2 TexCoord;
    uniform vec4 color;
    void main() {
        gl_FragColor = texture2D(Texture, TexCoord) * color;
    }
]]
-- Rounded rectangles and circles share a signed-distance mask.
local panel = resource.create_shader[[
    uniform sampler2D Texture;
    varying vec2 TexCoord;
    uniform vec2 dimensions;
    uniform float radius;
    uniform float circle;
    uniform vec4 background;
    uniform vec4 accent;
    uniform float thickness;
    void main() {
        vec2 point = (TexCoord - vec2(0.5)) * dimensions;
        vec2 edge = abs(point) - dimensions * 0.5 + vec2(radius);
        float distance = length(max(edge, vec2(0.0))) + min(max(edge.x, edge.y), 0.0) - radius;
        float coverage = 1.0 - smoothstep(-1.0, 0.0, distance);
        float top = step(TexCoord.y * dimensions.y, thickness) * step(0.001, thickness);
        if (circle > 0.5) top = step(point.y, 0.0) * step(-thickness, distance) * step(0.001, thickness);
        gl_FragColor = texture2D(Texture, TexCoord) * mix(background, accent, top) * coverage;
    }
]]
-- One additional draw per animated frame, with no snapshots or new textures.
local effect_shader = resource.create_shader[[
    uniform sampler2D Texture;
    varying vec2 TexCoord;
    uniform vec2 dimensions;
    uniform float radius;
    uniform vec4 color;
    uniform float strength;
    uniform float glow;
    void main() {
        vec2 point = (TexCoord - vec2(0.5)) * dimensions;
        vec2 edge = abs(point) - dimensions * 0.5 + vec2(radius);
        float distance = length(max(edge, vec2(0.0))) + min(max(edge.x, edge.y), 0.0) - radius;
        float coverage = 1.0 - smoothstep(-1.0, 0.0, distance);
        float band = smoothstep(-3.0, -2.0, distance);
        if (glow > 0.5) band = exp(min(distance, 0.0) / 3.0) * smoothstep(-12.0, -10.0, distance);
        gl_FragColor = texture2D(Texture, TexCoord) * color * (coverage * band * strength);
    }
]]
-- Repeats a circular mask along each horizontal run; no per-module textures.
local dotted = resource.create_shader[[
    uniform sampler2D Texture;
    varying vec2 TexCoord;
    uniform float columns;
    uniform float feather;
    void main() {
        vec2 point = vec2(fract(TexCoord.x * columns), TexCoord.y) - vec2(0.5);
        float alpha = 1.0 - smoothstep(0.5 - feather, 0.5, length(point));
        gl_FragColor = texture2D(Texture, TexCoord) * alpha;
    }
]]
local white = resource.create_colored_texture(1,1,1,1)
local black = resource.create_colored_texture(0,0,0,1)
-- The verified Scheduled Player loads this same font in its root namespace.
local font = resource.load_font('default-font.ttf')
local logo
local cache,order = {},{}
local M = {}
function M.updated_config_json(config)
    if logo then logo:dispose(); logo=nil end
    if config.logo and config.logo.asset_name then
        logo=resource.load_image(api.localized(config.logo.asset_name))
    end
end
local function prepare(payload)
    if cache[payload] then return cache[payload] end
    local matrix,reserved=qr.encode(payload)
    local runs={}
    for y,row in ipairs(matrix) do
        local x=1
        while x<=#row do
            if row[x] then
                local start=x
                local functional=reserved[y][x]==true
                repeat x=x+1 until x>#row or not row[x] or (reserved[y][x]==true)~=functional
                runs[#runs+1]={start-1,y-1,x-start,functional}
            else x=x+1 end
        end
    end
    local result={modules=#matrix,runs=runs}
    cache[payload]=result; order[#order+1]=payload
    if #order>8 then cache[table.remove(order,1)]=nil end
    return result
end
local function rectangle(color,x1,y1,x2,y2)
    colored:use{color=color}
    white:draw(x1,y1,x2,y2)
    colored:deactivate()
end
local function label(text,x,y,size,max_width,align,color)
    -- Bound font width without splitting a UTF-8 codepoint.
    local value=text
    while #value>0 and font:width(value,size)>max_width do
        value=value:gsub('[%z\1-\127\194-\244][\128-\191]*$','')
    end
    local width=font:width(value,size)
    if align=='center' then x=x+math.floor((max_width-width)/2)
    elseif align=='right' then x=x+max_width-width end
    color=color or {1,1,1,1}
    font:write(x,y,value,size,color[1],color[2],color[3],color[4])
end
local function bounded(value,default,low,high)
    value=tonumber(value)
    if not value or value~=value then value=default end
    return math.max(low,math.min(high,value))
end
local function hint_icon(kind,x,y,size,color)
    local t=math.max(1,math.floor(size/12))
    local w=kind=='phone' and size*0.65 or size
    rectangle(color,x,y,x+w,y+t);rectangle(color,x,y+size-t,x+w,y+size)
    rectangle(color,x,y,x+t,y+size);rectangle(color,x+w-t,y,x+w,y+size)
    if kind=='phone' then rectangle(color,x+w*0.4,y+size-t*3,x+w*0.6,y+size-t*2)
    else
        rectangle(color,x,y+size*0.28,x+w,y+size*0.28+t)
        rectangle(color,x+w*0.25,y-t,x+w*0.25+t,y+t*2)
        rectangle(color,x+w*0.75,y-t,x+w*0.75+t,y+t*2)
    end
end
function M.task(starts,ends,config,x1,y1,x2,y2)
    local ok,prepared=pcall(function() return prepare(model.payload(config)) end)
    local background=model.color(config.background_color,{0.025,0.08,0.19,1})
    local accent=model.color(config.accent_color,{0.8,0.08,0.16,1})
    background[4]=bounded(config.background_opacity,100,0,100)/100
    local thickness=bounded(config.accent_thickness,4,0,32)
    local effect=model.effect(config)
    local effect_args
    local text_color=model.color(config.text_color,{1,1,1,1})
    local layout,err
    if ok then layout,err=model.layout(config,x1,y1,x2,y2,prepared.modules,function(value,size) return font:width(value,size) end) end
    if layout and effect.kind~='off' and effect.intensity>0 then
        effect_args={dimensions={layout.w,layout.h},
            radius=layout.shape=='circle' and layout.w/2 or layout.shape=='rounded' and math.min(layout.radius,layout.w/2,layout.h/2) or 0,
            color=effect.color,glow=effect.kind=='glow' and 1 or 0,strength=0}
    end
    local message=not ok and tostring(prepared):gsub('^.-:%d+: ','') or err
    if not ok or not layout then
        -- Do not log private URLs/contact data from an encoder exception.
        print('DUWO QR: ungültige Konfiguration oder Element zu klein')
    end
    for now in api.frame_between(starts,ends) do
        if ok and layout then
            local p=layout
            if p.shape=='rectangle' then
                rectangle(background,p.x,p.y,p.x+p.w,p.y+p.h)
                rectangle(accent,p.x,p.y,p.x+p.w,p.y+thickness)
            else
                panel:use{dimensions={p.w,p.h},radius=p.shape=='circle' and p.w/2 or math.min(p.radius,p.w/2,p.h/2),
                    thickness=thickness,circle=p.shape=='circle' and 1 or 0,background=background,accent=accent}
                white:draw(p.x,p.y,p.x+p.w,p.y+p.h)
                panel:deactivate()
            end
            if effect_args then
                effect_args.strength=model.effect_alpha(effect,now-starts)
                effect_shader:use(effect_args)
                white:draw(p.x,p.y,p.x+p.w,p.y+p.h)
                effect_shader:deactivate()
            end
            -- QR, opaque quiet zone, text and logo are drawn after the effect.
            white:draw(p.qx,p.qy,p.qx+p.side,p.qy+p.side)
            local s=p.scale
            for _,run in ipairs(prepared.runs) do
                local x,y=p.qx+(run[1]+4)*s,p.qy+(run[2]+4)*s
                local round=config.module_style=='dots' and not run[4]
                if round then dotted:use{columns=run[3],feather=0.5/s} end
                black:draw(x,y,x+run[3]*s,y+s)
                if round then dotted:deactivate() end
            end
            if p.footer>0 then
                if p.logo and logo then
                    util.draw_correct(logo,p.lx,p.ly,p.lx+p.logo_size,p.ly+p.logo_size)
                end
                if p.icon~='none' then hint_icon(p.icon,p.ix,p.iy,p.font_size,text_color) end
                for index,line in ipairs(p.lines) do
                    label(line,p.tx,p.ty+(index-1)*p.line_height,p.font_size,p.text_width,config.text_align,text_color)
                end
            end
        elseif x2-x1>=160 and y2-y1>=50 then
            navy:draw(x1,y1,x2,math.min(y2,y1+50))
            label(message or 'QR-Konfiguration prüfen',x1+8,y1+10,20,x2-x1-16)
        end
    end
end
function M.unload()
    if logo then logo:dispose() end
    navy:dispose(); colored:dispose(); panel:dispose(); effect_shader:dispose(); dotted:dispose(); white:dispose(); black:dispose()
end
return M
