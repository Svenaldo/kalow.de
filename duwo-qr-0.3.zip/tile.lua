local api = ...
-- Nested plugin modules must be explicitly localized: require() searches the parent.
local function local_module(name)
    return assert(loadstring(resource.load_file(api.localized(name))))()
end
local qr = local_module('qr.lua')
local model = local_module('model.lua')
local navy = resource.create_colored_texture(0.025,0.08,0.19,1)
local red = resource.create_colored_texture(0.8,0.08,0.16,1)
local white = resource.create_colored_texture(1,1,1,1)
local black = resource.create_colored_texture(0,0,0,1)
-- The verified Scheduled Player loads this same font in its root namespace.
local font = resource.load_font('default-font.ttf')
local logo
local cache,order = {},{}
local M = {}
function M.updated_config_json(config)
    if logo then logo:dispose(); logo=nil end
    if config.logo and config.logo.asset_name then
        logo=resource.load_image(api.localized(config.logo.asset_name))
    end
end
local function prepare(payload)
    if cache[payload] then return cache[payload] end
    local matrix=qr.encode(payload)
    local runs={}
    for y,row in ipairs(matrix) do
        local x=1
        while x<=#row do
            if row[x] then
                local start=x
                repeat x=x+1 until x>#row or not row[x]
                runs[#runs+1]={start-1,y-1,x-start}
            else x=x+1 end
        end
    end
    local result={modules=#matrix,runs=runs}
    cache[payload]=result; order[#order+1]=payload
    if #order>8 then cache[table.remove(order,1)]=nil end
    return result
end
local function label(text,x,y,size,max_width)
    -- Bound font width without splitting a UTF-8 codepoint.
    local value=text
    while #value>0 and font:width(value,size)>max_width do
        value=value:gsub('[%z\1-\127\194-\244][\128-\191]*$','')
    end
    font:write(x,y,value,size,1,1,1,1)
end
function M.task(starts,ends,config,x1,y1,x2,y2)
    local ok,prepared=pcall(function() return prepare(model.payload(config)) end)
    local layout,err
    if ok then layout,err=model.layout(config,x1,y1,x2,y2,prepared.modules) end
    if not ok or not layout then
        -- Do not log private URLs/contact data from an encoder exception.
        print('DUWO QR: ungültige Konfiguration oder Element zu klein')
    end
    for now in api.frame_between(starts,ends) do
        if ok and layout then
            local p=layout
            navy:draw(p.x,p.y,p.x+p.w,p.y+p.h)
            red:draw(p.x,p.y,p.x+p.w,p.y+4)
            white:draw(p.qx,p.qy,p.qx+p.side,p.qy+p.side)
            local s=p.scale
            for _,run in ipairs(prepared.runs) do
                local x,y=p.qx+(run[1]+4)*s,p.qy+(run[2]+4)*s
                black:draw(x,y,x+run[3]*s,y+s)
            end
            if p.footer>0 then
                local tx=p.x+12
                local ty=p.y+p.h-54
                if p.logo and logo then
                    util.draw_correct(logo,tx,ty,tx+44,ty+44)
                    tx=tx+54
                end
                label(p.text,tx,ty+10,22,p.x+p.w-12-tx)
            end
        elseif x2-x1>=160 and y2-y1>=50 then
            navy:draw(x1,y1,x2,math.min(y2,y1+50))
            label('QR prüfen: Inhalt / Größe',x1+8,y1+10,20,x2-x1-16)
        end
    end
end
function M.unload()
    if logo then logo:dispose() end
    navy:dispose(); red:dispose(); white:dispose(); black:dispose()
end
return M
