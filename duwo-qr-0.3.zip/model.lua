-- Configuration and geometry; independent of the info-beamer runtime.
local M = {}
local floor = math.floor
local function str(v) return type(v)=='string' and v or '' end
local function clean(v) return str(v):match('^%s*(.-)%s*$') end
local function single(v) return clean(v):gsub('[%z\1-\31\127]', '') end
local function esc(v)
    return str(v):gsub('\\','\\\\'):gsub('\r\n','\n'):gsub('\r','\n'):gsub('\n','\\n'):gsub(';','\\;'):gsub(',','\\,')
end
local function num(value, fallback, low, high)
    local n = tonumber(value)
    if not n or n~=n then n=fallback end
    return floor(math.max(low,math.min(high,n)))
end
local function leap(year)
    return year%4==0 and (year%100~=0 or year%400==0)
end
local function month_days(year,month)
    return ({31,leap(year) and 29 or 28,31,30,31,30,31,31,30,31,30,31})[month]
end
local function last_sunday(year,month)
    local days=365*(year-2000)+floor((year-1)/4)-floor(1999/4)
        -floor((year-1)/100)+floor(1999/100)+floor((year-1)/400)-floor(1999/400)
    for m=1,month-1 do days=days+month_days(year,m) end
    return 31-(days+30+6)%7 -- 2000-01-01 was Saturday.
end
local function event_time(value,zone)
    local year,month,day,hour,minute=str(value):match('^(%d%d%d%d)%-(%d%d)%-(%d%d)T(%d%d):(%d%d)$')
    year,month,day,hour,minute=tonumber(year),tonumber(month),tonumber(day),tonumber(hour),tonumber(minute)
    assert(year and year>=2000 and year<=2099 and month>=1 and month<=12
        and day>=1 and day<=month_days(year,month) and hour<=23 and minute<=59,
        'Termin: gültiges Datum und Uhrzeit (2000–2099) erforderlich')
    local offset=0
    if zone=='Europe/Berlin' then
        local march,october=last_sunday(year,3),last_sunday(year,10)
        assert(not ((month==3 and day==march or month==10 and day==october) and hour==2),
            'Termin: 02 Uhr bei Zeitumstellung ist nicht eindeutig oder existiert nicht')
        local summer=(month>3 and month<10) or (month==3 and (day>march or day==march and hour>=3))
            or (month==10 and (day<october or day==october and hour<2))
        offset=summer and 2 or 1
    else
        assert(zone=='UTC','Unbekannte Termin-Zeitzone')
    end
    hour=hour-offset
    if hour<0 then
        hour=hour+24;day=day-1
        if day==0 then
            month=month-1
            if month==0 then month=12;year=year-1 end
            day=month_days(year,month)
        end
    end
    return string.format('%04d%02d%02dT%02d%02d00Z',year,month,day,hour,minute)
end
-- Fold content lines without splitting UTF-8 codepoints (RFC 5545).
local function calendar_lines(lines)
    local result={}
    for _,line in ipairs(lines) do
        local limit=75
        while #line>limit do
            local count=limit
            while line:byte(count+1)>=128 and line:byte(count+1)<192 do count=count-1 end
            result[#result+1]=line:sub(1,count)
            line=' '..line:sub(count+1)
        end
        result[#result+1]=line
    end
    return table.concat(result,'\r\n')..'\r\n'
end
-- HTML color inputs supply #RRGGBB; reject malformed saved configuration.
function M.color(value, fallback)
    if type(value)~='string' or not value:match('^#%x%x%x%x%x%x$') then return fallback end
    return {tonumber(value:sub(2,3),16)/255,tonumber(value:sub(4,5),16)/255,
        tonumber(value:sub(6,7),16)/255,1}
end
-- Static parameters are prepared once per task; only a sine is evaluated per frame.
function M.effect(c)
    local kind=c.effect
    if kind~='pulse' and kind~='glow' then kind='off' end
    local period=({slow=6,normal=4,fast=2})[c.effect_speed] or 4
    local color=M.color(c.accent_color,{0.8,0.08,0.16,1})
    if c.effect_custom_color==true then color=M.color(c.effect_color,color) end
    return {kind=kind,period=period,intensity=num(c.effect_intensity,40,0,100)/100,color=color}
end
function M.effect_alpha(effect,elapsed)
    if effect.kind=='off' then return 0 end
    local wave=(1-math.cos(2*math.pi*math.max(0,elapsed)/effect.period))/2
    return effect.intensity*(0.25+0.75*wave)
end
function M.payload(c)
    local mode = c.mode or 'url'
    if mode=='url' then
        local url=clean(c.url or 'https://www.duwo08.de')
        assert(url:match('^https?://[^%s/]+') and not url:find('[%z\1-\32\127]'), 'HTTP(S)-URL fehlt oder ist ungültig')
        return url
    elseif mode=='email' then
        local email=single(c.email)
        assert(email:match('^[^%s@?&#]+@[^%s@?&#]+%.[^%s@?&#]+$'), 'E-Mail-Adresse fehlt oder ist ungültig')
        return 'mailto:'..email
    elseif mode=='phone' then
        local phone=single(c.phone):gsub('[%s()%-%.]','')
        assert(phone:match('^%+?%d+$'), 'Telefonnummer fehlt oder ist ungültig')
        return 'tel:'..phone
    elseif mode=='event' then
        local title=single(c.event_title)
        assert(title~='', 'Termin-Titel fehlt')
        local zone=c.event_timezone or 'Europe/Berlin'
        local starts,ends
        if c.event_all_day==true then
            local first=single(c.event_start_date)
            local last=single(c.event_end_date)
            starts=event_time(first..'T12:00','UTC'):sub(1,8)
            ends=event_time(last..'T12:00','UTC'):sub(1,8)
            assert(ends>=starts,'Letzter Termintag muss nach oder am ersten Tag liegen')
            local y,m,d=tonumber(ends:sub(1,4)),tonumber(ends:sub(5,6)),tonumber(ends:sub(7,8))
            d=d+1
            if d>month_days(y,m) then d=1;m=m+1;if m>12 then m=1;y=y+1 end end
            ends=string.format('%04d%02d%02d',y,m,d)
        else
            starts=event_time(c.event_start,zone)
            ends=event_time(c.event_end,zone)
            assert(ends>starts,'Termin-Ende muss nach dem Beginn liegen')
        end
        -- Compact VEVENT barcode content, as documented by ZXing; no ICS wrapper.
        local suffix=c.event_all_day==true and ';VALUE=DATE' or ''
        local lines={'BEGIN:VEVENT','SUMMARY:'..esc(title),'DTSTART'..suffix..':'..starts,'DTEND'..suffix..':'..ends}
        local location=single(c.event_location)
        if location~='' then lines[#lines+1]='LOCATION:'..esc(location) end
        local description=clean(c.event_description):gsub('[%z\1-\8\11\12\14-\31\127]','')
        if description~='' then lines[#lines+1]='DESCRIPTION:'..esc(description) end
        lines[#lines+1]='END:VEVENT'
        return calendar_lines(lines)
    elseif mode=='vcard' then
        local first,last=single(c.first_name),single(c.last_name)
        assert(first~='' or last~='', 'Kontaktname fehlt')
        local lines={'BEGIN:VCARD','VERSION:3.0','N:'..esc(last)..';'..esc(first)..';;;',
            'FN:'..esc(clean(first..' '..last))}
        for _,field in ipairs({{'ORG',c.organization},{'EMAIL',c.email},{'TEL',c.phone},{'URL',c.contact_url}}) do
            local value=single(field[2])
            if value~='' then lines[#lines+1]=field[1]..':'..esc(value) end
        end
        lines[#lines+1]='END:VCARD'
        return table.concat(lines,'\r\n')..'\r\n'
    end
    error('Unbekannter QR-Typ')
end
-- UTF-8-aware wrapping. Long words are split only between codepoints.
function M.text_lines(text,size,width,wrap,measure)
    measure=measure or function(value,font_size) return #value*font_size/2 end
    local lines={}
    text=str(text):gsub('\r\n','\n'):gsub('\r','\n'):gsub('[%z\1-\9\11-\31\127]','')
    if not wrap then text=text:gsub('\n',' ' ) end
    for paragraph in (text..'\n'):gmatch('(.-)\n') do
        local line=''
        for char in paragraph:gmatch('[%z\1-\127\194-\244][\128-\191]*') do
            if measure(line..char,size)>width then
                if wrap and #line>0 then
                    local prefix,suffix=line:match('^(.*)%s+([^%s]*)$')
                    if prefix and #prefix>0 then lines[#lines+1]=prefix;line=suffix
                    else lines[#lines+1]=line;line='' end
                    if measure(line..char,size)>width and #line>0 then lines[#lines+1]=line;line='' end
                end
                if not wrap then break end
            end
            if measure(char,size)<=width and not (line=='' and char==' ') then line=line..char end
        end
        lines[#lines+1]=line
    end
    -- Avoid unbounded work/height from accidentally pasted prose.
    while #lines>12 do table.remove(lines) end
    return lines
end
function M.layout(c,x1,y1,x2,y2,modules,measure)
    local width,height=floor(x2-x1),floor(y2-y1)
    if width<=0 or height<=0 then return nil,'Elementfläche fehlt' end
    local margin=num(c.margin,16,0,500)
    local size=num(c.size,260,64,1600)
    local font_size=num(c.font_size,22,10,96)
    local text=c.text==nil and 'Jetzt scannen' or str(c.text)
    local logo=c.show_logo==true
    local logo_size=num(c.logo_size,44,16,160)
    local logo_position=c.logo_position or 'left'
    local icon=(c.hint_icon=='phone' or c.hint_icon=='calendar') and c.hint_icon or 'none'
    local present=clean(text)~='' or logo or icon~='none'
    local shape=c.panel_shape
    if shape~='rounded' and shape~='circle' then shape='rectangle' end
    local radius=num(c.corner_radius,20,0,120)
    local padding=num(c.padding,12,0,120)
    if shape=='rounded' then padding=math.max(padding,math.ceil(radius*(1-1/math.sqrt(2)))+1) end
    local position=c.text_position or 'below'
    if position~='above' and position~='left' and position~='right' then position='below' end
    local horizontal=position=='left' or position=='right'
    local function dimensions(qr_size)
        local bw=horizontal and num(c.text_width,220,60,600) or qr_size
        local tw=bw
        if logo and (logo_position=='left' or logo_position=='right') then tw=tw-logo_size-10 end
        if icon~='none' then tw=tw-font_size-8 end
        tw=math.max(1,tw)
        local lines=M.text_lines(text,font_size,tw,c.text_wrap==true,measure)
        local line_height=math.ceil(font_size*1.25)
        local th=clean(text)~='' and #lines*line_height or 0
        if icon~='none' then th=math.max(th,font_size) end
        local bh=math.max(64,th+20)
        if logo then
            if logo_position=='above' or logo_position=='below' then bh=math.max(64,th+logo_size+30)
            else bh=math.max(bh,logo_size+20) end
        end
        local iw,ih=qr_size,qr_size
        if present then
            if horizontal then iw=qr_size+12+bw;ih=math.max(qr_size,bh)
            else ih=qr_size+bh end
        end
        local cw,ch=iw+padding*2,ih+padding*2
        local pw,ph=cw,ch
        if shape=='circle' then pw=math.ceil(math.sqrt(cw*cw+ch*ch))+8;ph=pw end
        return {w=pw,h=ph,cw=cw,ch=ch,bw=bw,bh=bh,tw=tw,th=th,lines=lines,line_height=line_height}
    end
    local d=dimensions(size)
    if d.w+margin*2>width or d.h+margin*2>height then
        local low,high=0,size
        while low<high do
            local mid=math.ceil((low+high)/2)
            local candidate=dimensions(mid)
            if candidate.w+margin*2<=width and candidate.h+margin*2<=height then low=mid else high=mid-1 end
        end
        size=low;d=dimensions(size)
    end
    if clean(text)~='' and d.tw<font_size then return nil,'Textfläche zu schmal: Textbreite vergrößern oder Logo/Symbol verkleinern' end
    if logo and d.bw<logo_size then return nil,'Logo zu groß: Logo verkleinern oder QR-Fläche vergrößern' end
    local scale=floor(size/(modules+8))
    if scale<2 or d.w+margin*2>width or d.h+margin*2>height then
        return nil,'QR zu klein: Element vergrößern oder Text/Logo verkleinern'
    end
    local pos=c.position or 'bottom_right'
    local x,y=margin,margin
    if pos=='custom' then
        x=num(c.x,16,0,math.max(0,width-d.w));y=num(c.y,16,0,math.max(0,height-d.h))
    else
        if pos:find('right',1,true) then x=width-d.w-margin end
        if pos:find('bottom',1,true) then y=height-d.h-margin end
        if pos=='center' then x=floor((width-d.w)/2);y=floor((height-d.h)/2) end
    end
    local px,py=floor(x1+x),floor(y1+y)
    local cx,cy=px+floor((d.w-d.cw)/2),py+floor((d.h-d.ch)/2)
    local qx,qy=cx+padding,cy+padding
    local bx,by=qx,qy
    if present then
        if horizontal then
            qy=qy+floor((d.ch-padding*2-size)/2)
            by=by+floor((d.ch-padding*2-d.bh)/2)
            if position=='left' then qx=qx+d.bw+12 else bx=bx+size+12 end
        elseif position=='above' then qy=qy+d.bh
        else by=by+size end
    end
    local tx,ty=bx,by+floor((d.bh-d.th)/2)
    local lx,ly=bx,by+floor((d.bh-logo_size)/2)
    if logo then
        if logo_position=='right' then lx=bx+d.bw-logo_size
        elseif logo_position=='above' or logo_position=='below' then
            lx=bx+floor((d.bw-logo_size)/2)
            local top=by+floor((d.bh-d.th-logo_size-10)/2)
            if logo_position=='above' then ly=top;ty=top+logo_size+10
            else ty=top;ly=top+d.th+10 end
        else tx=tx+logo_size+10 end
    end
    local ix,iy=tx,ty
    if icon~='none' then tx=tx+font_size+8 end
    return {x=px,y=py,w=d.w,h=d.h,shape=shape,radius=radius,
        cx=cx,cy=cy,cw=d.cw,ch=d.ch,qx=qx+floor((size-(modules+8)*scale)/2),
        qy=qy+floor((size-(modules+8)*scale)/2),scale=scale,side=(modules+8)*scale,
        footer=present and d.bh or 0,text=text,logo=logo,lx=lx,ly=ly,logo_size=logo_size,
        tx=tx,ty=ty,text_width=d.tw,lines=d.lines,font_size=font_size,line_height=d.line_height,
        icon=icon,ix=ix,iy=iy}
end
return M
