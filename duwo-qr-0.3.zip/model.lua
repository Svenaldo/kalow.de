-- Configuration and geometry; independent of the info-beamer runtime.
local M = {}
local floor = math.floor
local function str(v) return type(v)=='string' and v or '' end
local function clean(v) return str(v):match('^%s*(.-)%s*$') end
local function single(v) return clean(v):gsub('[%z\1-\31\127]', '') end
local function esc(v)
    return str(v):gsub('\\','\\\\'):gsub('\r\n','\n'):gsub('\r','\n'):gsub('\n','\\n'):gsub(';','\\;'):gsub(',','\\,')
end
local function num(value, fallback, low, high)
    local n = tonumber(value)
    if not n or n~=n then n=fallback end
    return floor(math.max(low,math.min(high,n)))
end
function M.payload(c)
    local mode = c.mode or 'url'
    if mode=='url' then
        local url=clean(c.url or 'https://www.duwo08.de')
        assert(url:match('^https?://[^%s/]+') and not url:find('[%z\1-\32\127]'), 'HTTP(S)-URL fehlt oder ist ungültig')
        return url
    elseif mode=='email' then
        local email=single(c.email)
        assert(email:match('^[^%s@?&#]+@[^%s@?&#]+%.[^%s@?&#]+$'), 'E-Mail-Adresse fehlt oder ist ungültig')
        return 'mailto:'..email
    elseif mode=='phone' then
        local phone=single(c.phone):gsub('[%s()%-%.]','')
        assert(phone:match('^%+?%d+$'), 'Telefonnummer fehlt oder ist ungültig')
        return 'tel:'..phone
    elseif mode=='vcard' then
        local first,last=single(c.first_name),single(c.last_name)
        assert(first~='' or last~='', 'Kontaktname fehlt')
        local lines={'BEGIN:VCARD','VERSION:3.0','N:'..esc(last)..';'..esc(first)..';;;',
            'FN:'..esc(clean(first..' '..last))}
        for _,field in ipairs({{'ORG',c.organization},{'EMAIL',c.email},{'TEL',c.phone},{'URL',c.contact_url}}) do
            local value=single(field[2])
            if value~='' then lines[#lines+1]=field[1]..':'..esc(value) end
        end
        lines[#lines+1]='END:VCARD'
        return table.concat(lines,'\r\n')..'\r\n'
    end
    error('Unbekannter QR-Typ')
end
function M.layout(c,x1,y1,x2,y2,modules)
    local width,height=floor(x2-x1),floor(y2-y1)
    if width<=0 or height<=0 then return nil,'Elementfläche fehlt' end
    local margin=num(c.margin,16,0,500)
    local size=num(c.size,260,64,1600)
    local text=single(c.text)
    local logo=c.show_logo==true
    local footer=(text~='' or logo) and 64 or 0
    local panel_w,panel_h=size+24,size+24+footer
    if panel_w+margin*2>width or panel_h+margin*2>height then
        size=math.min(width-margin*2-24,height-margin*2-24-footer)
        panel_w,panel_h=size+24,size+24+footer
    end
    local scale=floor(size/(modules+8))
    if scale<2 then return nil,'QR zu klein: Element vergrößern oder Inhalt kürzen' end
    local pos=c.position or 'bottom_right'
    local x,y=margin,margin
    if pos=='custom' then
        x=num(c.x,16,0,math.max(0,width-panel_w))
        y=num(c.y,16,0,math.max(0,height-panel_h))
    else
        if pos:find('right',1,true) then x=width-panel_w-margin end
        if pos:find('bottom',1,true) then y=height-panel_h-margin end
        if pos=='center' then x=floor((width-panel_w)/2); y=floor((height-panel_h)/2) end
    end
    return {x=floor(x1+x),y=floor(y1+y),w=panel_w,h=panel_h,
        qx=floor(x1+x+12+(size-(modules+8)*scale)/2),qy=floor(y1+y+12+(size-(modules+8)*scale)/2),
        scale=scale,side=(modules+8)*scale,footer=footer,text=text,logo=logo}
end
return M
