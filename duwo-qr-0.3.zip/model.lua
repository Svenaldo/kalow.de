-- Configuration and geometry; independent of the info-beamer runtime.
local M = {}
local floor = math.floor
local function str(v) return type(v)=='string' and v or '' end
local function clean(v) return str(v):match('^%s*(.-)%s*$') end
local function single(v) return clean(v):gsub('[%z\1-\31\127]', '') end
local function esc(v)
    return str(v):gsub('\\','\\\\'):gsub('\r\n','\n'):gsub('\r','\n'):gsub('\n','\\n'):gsub(';','\\;'):gsub(',','\\,')
end
local function num(value, fallback, low, high)
    local n = tonumber(value)
    if not n or n~=n then n=fallback end
    return floor(math.max(low,math.min(high,n)))
end
local function leap(year)
    return year%4==0 and (year%100~=0 or year%400==0)
end
local function month_days(year,month)
    return ({31,leap(year) and 29 or 28,31,30,31,30,31,31,30,31,30,31})[month]
end
local function last_sunday(year,month)
    local days=365*(year-2000)+floor((year-1)/4)-floor(1999/4)
        -floor((year-1)/100)+floor(1999/100)+floor((year-1)/400)-floor(1999/400)
    for m=1,month-1 do days=days+month_days(year,m) end
    return 31-(days+30+6)%7 -- 2000-01-01 was Saturday.
end
local function event_time(value,zone)
    local year,month,day,hour,minute=str(value):match('^(%d%d%d%d)%-(%d%d)%-(%d%d)T(%d%d):(%d%d)$')
    year,month,day,hour,minute=tonumber(year),tonumber(month),tonumber(day),tonumber(hour),tonumber(minute)
    assert(year and year>=2000 and year<=2099 and month>=1 and month<=12
        and day>=1 and day<=month_days(year,month) and hour<=23 and minute<=59,
        'Termin: gültiges Datum und Uhrzeit (2000–2099) erforderlich')
    local offset=0
    if zone=='Europe/Berlin' then
        local march,october=last_sunday(year,3),last_sunday(year,10)
        assert(not ((month==3 and day==march or month==10 and day==october) and hour==2),
            'Termin: 02 Uhr bei Zeitumstellung ist nicht eindeutig oder existiert nicht')
        local summer=(month>3 and month<10) or (month==3 and (day>march or day==march and hour>=3))
            or (month==10 and (day<october or day==october and hour<2))
        offset=summer and 2 or 1
    else
        assert(zone=='UTC','Unbekannte Termin-Zeitzone')
    end
    hour=hour-offset
    if hour<0 then
        hour=hour+24;day=day-1
        if day==0 then
            month=month-1
            if month==0 then month=12;year=year-1 end
            day=month_days(year,month)
        end
    end
    return string.format('%04d%02d%02dT%02d%02d00Z',year,month,day,hour,minute)
end
-- Fold content lines without splitting UTF-8 codepoints (RFC 5545).
local function calendar_lines(lines)
    local result={}
    for _,line in ipairs(lines) do
        local limit=75
        while #line>limit do
            local count=limit
            while line:byte(count+1)>=128 and line:byte(count+1)<192 do count=count-1 end
            result[#result+1]=line:sub(1,count)
            line=' '..line:sub(count+1)
        end
        result[#result+1]=line
    end
    return table.concat(result,'\r\n')..'\r\n'
end
-- HTML color inputs supply #RRGGBB; reject malformed saved configuration.
function M.color(value, fallback)
    if type(value)~='string' or not value:match('^#%x%x%x%x%x%x$') then return fallback end
    return {tonumber(value:sub(2,3),16)/255,tonumber(value:sub(4,5),16)/255,
        tonumber(value:sub(6,7),16)/255,1}
end
function M.payload(c)
    local mode = c.mode or 'url'
    if mode=='url' then
        local url=clean(c.url or 'https://www.duwo08.de')
        assert(url:match('^https?://[^%s/]+') and not url:find('[%z\1-\32\127]'), 'HTTP(S)-URL fehlt oder ist ungültig')
        return url
    elseif mode=='email' then
        local email=single(c.email)
        assert(email:match('^[^%s@?&#]+@[^%s@?&#]+%.[^%s@?&#]+$'), 'E-Mail-Adresse fehlt oder ist ungültig')
        return 'mailto:'..email
    elseif mode=='phone' then
        local phone=single(c.phone):gsub('[%s()%-%.]','')
        assert(phone:match('^%+?%d+$'), 'Telefonnummer fehlt oder ist ungültig')
        return 'tel:'..phone
    elseif mode=='event' then
        local title=single(c.event_title)
        assert(title~='', 'Termin-Titel fehlt')
        local zone=c.event_timezone or 'Europe/Berlin'
        local starts=event_time(c.event_start,zone)
        local ends=event_time(c.event_end,zone)
        assert(ends>starts,'Termin-Ende muss nach dem Beginn liegen')
        -- Compact VEVENT barcode content, as documented by ZXing; no ICS wrapper.
        local lines={'BEGIN:VEVENT','SUMMARY:'..esc(title),'DTSTART:'..starts,'DTEND:'..ends}
        local location=single(c.event_location)
        if location~='' then lines[#lines+1]='LOCATION:'..esc(location) end
        local description=clean(c.event_description):gsub('[%z\1-\8\11\12\14-\31\127]','')
        if description~='' then lines[#lines+1]='DESCRIPTION:'..esc(description) end
        lines[#lines+1]='END:VEVENT'
        return calendar_lines(lines)
    elseif mode=='vcard' then
        local first,last=single(c.first_name),single(c.last_name)
        assert(first~='' or last~='', 'Kontaktname fehlt')
        local lines={'BEGIN:VCARD','VERSION:3.0','N:'..esc(last)..';'..esc(first)..';;;',
            'FN:'..esc(clean(first..' '..last))}
        for _,field in ipairs({{'ORG',c.organization},{'EMAIL',c.email},{'TEL',c.phone},{'URL',c.contact_url}}) do
            local value=single(field[2])
            if value~='' then lines[#lines+1]=field[1]..':'..esc(value) end
        end
        lines[#lines+1]='END:VCARD'
        return table.concat(lines,'\r\n')..'\r\n'
    end
    error('Unbekannter QR-Typ')
end
function M.layout(c,x1,y1,x2,y2,modules)
    local width,height=floor(x2-x1),floor(y2-y1)
    if width<=0 or height<=0 then return nil,'Elementfläche fehlt' end
    local margin=num(c.margin,16,0,500)
    local size=num(c.size,260,64,1600)
    local text=single(c.text)
    local logo=c.show_logo==true
    local footer=(text~='' or logo) and 64 or 0
    local panel_w,panel_h=size+24,size+24+footer
    if panel_w+margin*2>width or panel_h+margin*2>height then
        size=math.min(width-margin*2-24,height-margin*2-24-footer)
        panel_w,panel_h=size+24,size+24+footer
    end
    local scale=floor(size/(modules+8))
    if scale<2 then return nil,'QR zu klein: Element vergrößern oder Inhalt kürzen' end
    local pos=c.position or 'bottom_right'
    local x,y=margin,margin
    if pos=='custom' then
        x=num(c.x,16,0,math.max(0,width-panel_w))
        y=num(c.y,16,0,math.max(0,height-panel_h))
    else
        if pos:find('right',1,true) then x=width-panel_w-margin end
        if pos:find('bottom',1,true) then y=height-panel_h-margin end
        if pos=='center' then x=floor((width-panel_w)/2); y=floor((height-panel_h)/2) end
    end
    return {x=floor(x1+x),y=floor(y1+y),w=panel_w,h=panel_h,
        qx=floor(x1+x+12+(size-(modules+8)*scale)/2),qy=floor(y1+y+12+(size-(modules+8)*scale)/2),
        scale=scale,side=(modules+8)*scale,footer=footer,text=text,logo=logo}
end
return M
