# DUWO QR 0.3 – Scheduled Player Plugin

## Alpha release

Testversion für Scheduled Player 20 und Raspberry Pi Zero W.
Als Kindpaket des Scheduled Players installieren, anschließend als Seitenelement
hinzufügen. Kein eigenständiger Player.

URL, E-Mail, Telefonnummer oder vCard 3.0 pro Element konfigurieren. Positionen
und X/Y-Koordinaten beziehen sich auf dessen Rechteck. Für seitenweite Positionen
dieses Rechteck auf die ganze Seite vergrößern. Logo im Plugin-Reiter auswählen,
Anzeige im Element aktivieren. Mitgeliefert wird ein transparenter Platzhalter.

QR-Element über dem Hintergrund anordnen. Raw-Videos/Streams auf
**Show behind other content** setzen. Positive Hardware-Video-Layer überdecken
GL-Elemente unabhängig von deren Zeichenreihenfolge.

Keine externen Laufzeitabhängigkeiten. UTF-8, ECC M, QR-Versionen 1–10,
maximal 212 UTF-8-Bytes einschließlich Präfixen bzw. vCard-Gerüst. Längere Inhalte
werden abgewiesen. Mindestens zwei logische Pixel pro Modul; reale Scanbarkeit
und Video-Leistung vor produktiver Nutzung am Gerät prüfen. Der Renderer nutzt
die mit Scheduled Player 20 ausgelieferte Schrift.

[Quellcode, Installation, lokale Tests und GitHub-Veröffentlichung](https://github.com/Svenaldo/duwo-info-beamer)
und [Gerätetestplan](https://github.com/Svenaldo/duwo-info-beamer/blob/main/docs/device-test-plan.md).

### Textausrichtung und Farben

In den Seiteneinstellungen des QR-Elements lässt sich der Begleittext linksbündig,
mittig oder rechtsbündig ausrichten. Bei eingeblendetem Logo gilt die Ausrichtung
für die verbleibende Textfläche rechts neben dem Logo. Schriftfarbe, Hintergrundfarbe
und Farbe des oberen Akzentbalkens sind über Farbfelder wählbar. Bestehende
Konfigurationen behalten weißen Text, dunkelblauen Hintergrund und roten Akzent
sowie linksbündigen Text. QR-Module und weiße Ruhezone bleiben unverändert.

### Kalendertermin per QR-Code

Im Inhaltstyp **Kalendertermin** Titel, Beginn und Ende eingeben. Ort und
Beschreibung sind optional. Die Zeiten gelten standardmäßig für **Europe/Berlin**;
Sommer-/Winterzeit wird nach der aktuellen EU-Regel automatisch berücksichtigt.
Alternativ ist UTC wählbar. Unterstützter Datumsbereich: 2000–2099.
Die Stunde 02:00–02:59 an beiden Zeitumstellungstagen wird wegen fehlender bzw.
doppelter Ortszeiten abgewiesen. Das Ende muss nach dem Beginn liegen.

Der QR-Code enthält ein kompaktes `VEVENT`, wie in der
[ZXing-Formatdokumentation](https://github.com/zxing/zxing/wiki/Barcode-Contents#calendar-events)
beschrieben. Text-Escaping und UTF-8-Zeilenfaltung folgen
[RFC 5545](https://www.rfc-editor.org/rfc/rfc5545.html#section-3.1).
Es wird keine vollständige ICS-Datei mit VCALENDAR-Hülle erzeugt.
Die Kalenderübernahme hängt von der verwendeten Scanner-App ab und muss am
Smartphone geprüft werden; manche Kamera-Apps zeigen lediglich den Inhalt.

Beispiel: Titel „DUWO Training“, 20.10.2026 von 18:00 bis 19:30,
Ort „Sportplatz“, Beschreibung „Bitte kommen“. Insgesamt dürfen Terminformat
und Inhalte maximal **212 UTF-8-Bytes** belegen. Bei zu langem Inhalt Ort oder
Beschreibung kürzen. Ein größerer QR-Anzeigebereich erhöht diese Kapazität nicht.

### QR-Design: Quadrate oder Punkte

Unter **QR-Design** sind **Quadratische Module (Standard)** und **Runde Punkte**
wählbar. Bestehende Elemente behalten Quadrate. Bei Punkten bleiben alle
Funktionsmuster einschließlich der drei Erkennungsmarkierungen quadratisch.
QR-Inhalt, Fehlerkorrektur und weiße Ruhezone ändern sich nicht.
Die runden Datenmodule werden mit einem lokalen Shader gezeichnet, ohne neue
Bilddateien oder externe Abhängigkeiten. Horizontale Läufe werden weiterhin
zusammengefasst; das Punktdesign benötigt zusätzliche Shader-Aufrufe.
Für Punkte mindestens etwa sechs Ausgabepixel pro Modul anstreben und Scanbarkeit
sowie Pi-Zero-W-Leistung zusammen mit dem Hintergrundvideo prüfen.
