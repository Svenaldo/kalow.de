# DUWO QR 0.3 – Scheduled Player Plugin

## Alpha release

Für Scheduled Player 20, entwickelt für Raspberry Pi Zero W. Als Kindpaket und
anschließend als Element einer Seite hinzufügen. Kein eigenständiger Player.

## Inhalte

HTTP(S)-URL, E-Mail, Telefon, vCard 3.0 und Kalendertermin (kompaktes VEVENT).
Maximal 212 UTF-8-Bytes einschließlich Präfixen und Formatfeldern. Der Editor
zeigt Kapazität und konkrete Fehler. Termine unterstützen deutsche Ortszeit mit
Sommer-/Winterzeit, alternativ UTC. Bei ganztägigen Terminen ersten und letzten
Tag einschließlich wählen. Zeitraum 2000–2099; die Umstellungsstunde 02 Uhr
wird bei zeitgebundenen Terminen abgewiesen. Scanner-App-Kompatibilität prüfen.

## Darstellung

* Rechteck (Standard), abgerundetes Rechteck oder Kreis.
* Quadratische Module (Standard) oder Punkte; Funktionsmuster bleiben eckig.
* Farben für Schrift, Hintergrund und oberen Akzent; Hintergrund-Deckkraft
  0–100 %. Akzentstärke 0–32 px, Eckenradius und Innenabstand 0–120 px.
* Text oben/unten/links/rechts, Schriftgröße 10–96 px, Ausrichtung links/mittig/rechts.
  Optional Zeilenumbrüche und automatischer Wortumbruch, maximal zwölf Zeilen.
* Logo 16–160 px, links/rechts/oberhalb/unterhalb des Texts. Logo im Plugin-Reiter
  wählen; Standard ist ein transparenter Platzhalter. Logo bleibt außerhalb des QR-Codes.
* Optional Smartphone- oder Kalender-Symbol.
* Vorlagen für Mitgliedschaft, Probetraining, Spenden und Spieltermin. Nach dem
  Anwenden einer Linkvorlage eure tatsächliche Ziel-URL eingeben.

Bisherige Design-Standardwerte bleiben erhalten. Bei begrenzter Elementfläche
wird der QR-Code kleiner oder ein Fehler angezeigt. Für Kreisformen mehr Platz
vorsehen. Die weiße QR-Ruhezone bleibt unabhängig von der Hintergrundtransparenz
deckend und wird von Logo/Text nicht überlagert.

## Editor-Vorschau

Echte lokale QR-Vorschau, wahlweise vergrößert oder auf einer Testfläche.
Testbreite/-höhe passend zu den tatsächlichen Elementabmessungen setzen; die
Vorschau verändert nicht die Elementfläche im Player. Browser-Schrift kann leicht
abweichen. Das globale Plugin-Logo wird in der Vorschau als Platzhalter dargestellt.
Keine externen QR-Dienste und keine Netzwerkanfragen an die eingegebenen Ziele.

## Installation und Tests

QR-Element vor dem Hintergrund anordnen. Raw-Videos/Streams auf **Show behind
other content** setzen. Positive Hardware-Video-Layer überdecken GL-Elemente.
Keine zusätzlichen Laufzeitabhängigkeiten auf dem Pi. Die Darstellung nutzt
Schrift und API des Scheduled Players, Layoutberechnung erfolgt vor der Frameschleife.

[Quellcode, Build, lokale Tests und GitHub-Veröffentlichung](https://github.com/Svenaldo/duwo-info-beamer)
und [Gerätetestplan](https://github.com/Svenaldo/duwo-info-beamer/blob/main/docs/device-test-plan.md).
Auf dem Pi insbesondere Transparenz über Video, Symbole, Umbruch, echte Logos,
Punktdesign und Kalenderimport am Smartphone prüfen.

## Optionale Animation

Unter **Animation** stehen **Aus (Standard)**, **Pulsierender Rahmen** und
**Dezenter Leuchtring** zur Wahl. Beide Effekte folgen der gewählten Hintergrundform
(Rechteck, abgerundetes Rechteck oder Kreis). Der Leuchtsaum liegt am Rand innerhalb
der Elementfläche, damit er auch bei randnaher Position nicht abgeschnitten wird.

* Geschwindigkeit: langsam (6 Sekunden), normal (4 Sekunden), schnell (2 Sekunden).
* Intensität: 0–100 %, Standard 40 %; 0 deaktiviert die zusätzliche Darstellung.
* Effektfarbe: folgt standardmäßig der Akzentfarbe. Mit **Eigene Effektfarbe verwenden**
  lässt sich eine unabhängige Farbe auswählen.

Der Rahmen verändert sanft seine Deckkraft; der Leuchtring besitzt einen weich
nach innen auslaufenden Saum. Es gibt keine Größenänderung, kein Blinken und keine
Änderung am QR-Inhalt. QR-Code, deckende weiße Ruhezone, Logo und Text werden nach
dem Effekt gezeichnet und bleiben unverändert. Bestehende Elemente bleiben ohne
Animation. Hintergrundtransparenz und Akzentstärke sind unabhängig vom Effekt.

Die Editor-Vorschau animiert den Rand lokal per SVG. Auf dem Pi wird pro aktivem
Element ein zusätzlicher Shader-Zeichenaufruf pro Frame benötigt, ohne Snapshots,
Netzwerkzugriffe oder neu angelegte Texturen. QR und Layout werden nicht pro Frame
neu berechnet. Die tatsächliche Zusatzlast und Scanbarkeit während Videowiedergabe
auf dem Pi Zero W sind noch am Gerät zu prüfen. Für den ersten Test empfehlen
sich „Pulsierender Rahmen“, „Langsam“ und eine geringe Intensität.
