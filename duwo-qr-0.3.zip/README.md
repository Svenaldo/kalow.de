# DUWO QR 0.3 – Scheduled Player Plugin

Testversion für Scheduled Player 20 und Raspberry Pi Zero W.
Als Kindpaket des Scheduled Players installieren, anschließend als Seitenelement
hinzufügen. Kein eigenständiger Player.

URL, E-Mail, Telefonnummer oder vCard 3.0 pro Element konfigurieren. Positionen
und X/Y-Koordinaten beziehen sich auf dessen Rechteck. Für seitenweite Positionen
dieses Rechteck auf die ganze Seite vergrößern. Logo im Plugin-Reiter auswählen,
Anzeige im Element aktivieren. Mitgeliefert wird ein transparenter Platzhalter.

QR-Element über dem Hintergrund anordnen. Raw-Videos/Streams auf
**Show behind other content** setzen. Positive Hardware-Video-Layer überdecken
GL-Elemente unabhängig von deren Zeichenreihenfolge.

Keine externen Laufzeitabhängigkeiten. UTF-8, ECC M, QR-Versionen 1–10,
maximal 212 UTF-8-Bytes einschließlich Präfixen bzw. vCard-Gerüst. Längere Inhalte
werden abgewiesen. Mindestens zwei logische Pixel pro Modul; reale Scanbarkeit
und Video-Leistung vor produktiver Nutzung am Gerät prüfen. Der Renderer nutzt
die mit Scheduled Player 20 ausgelieferte Schrift.

[Quellcode, Installation, lokale Tests und GitHub-Veröffentlichung](https://github.com/Svenaldo/duwo-info-beamer)
und [Gerätetestplan](https://github.com/Svenaldo/duwo-info-beamer/blob/main/docs/device-test-plan.md).
